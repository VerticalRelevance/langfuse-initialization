import boto3

import json
import urllib.request
import urllib.error

def lambda_handler(event, context):
    dynamodb = boto3.client('dynamodb')
    response = dynamodb.list_tables()